let carro 
let carro1 = {
    marca : "ferrari" ,
    modelo : "488 GTB" ,
    year : "2015" ,
    kilometraje : "20030 km" ,
    kpg : "20 km por galón" 
}

let carro2 = {
    marca : "BMW" ,
    modelo :"¡X3" ,
    year : "2020" ,
    kilometraje :"30500 km" ,
    kpg : "85 km por galón"
}

let carro3 = {
    marca : "Chevrolet" ,
    modelo :"Corvette" ,
    year : "2013" ,
    kilometraje : "20000 km" ,
    kpg : "1000 km por galón" 
}

let carro4 = {
    marca : "Audi" ,
    modelo : "e-tron" ,
    year : "2018" ,
    kilometraje : "40150 km" ,
    kpg : "40 km por galón"
}

let carros = [carro1 , carro2 , carro3 , carro4]

let conductor = { 
    nombre : "Federico" ,
    edad : "25 años" ,
    ciudad : "Medellín" , 
    carros : carros 
}