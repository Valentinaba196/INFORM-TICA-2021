let a = parseFloat(prompt("ingrese x"))
let b = parseFloat(prompt("ingrese y"))
let z = a + b
alert (z) 
let x = a - b 
alert(x)
let y = a * b
alert(y)
let m = a / b
alert(m)
let n = a % b
alert(n) 
if (b== 0) {
    alert("no es posible calcular la división y el módulo")
}
