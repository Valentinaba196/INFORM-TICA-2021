function areaCirc (r)
{ let area = Math.PI* (Math.pow(r,3))
   return volumen
}

function max (a,b)
{
    if (a>b) {
        return a
    } else {
        return b
    }
}

function masLarga (p1,p2) {
         if (p1.legth>p2.legth) {
             return p1
         } else {
             return p2
         }
}
let p1 = prompt ("ingrese p1")
let p2 = prompt ("ingrese p2")
alert (`la más larga es ${masLarga (p1,p2)}`)

function imMasLarga (P1,P2) {
    if (P1.legth>P2.legth) {
        return P1
    } else {
        return P2
    }
}
let P1 = prompt ("Ingrese P1")
let P2 = prompt ("Ingrese P2") 
console.log (`la palabra más larga que se puede imprimir es ${imMasLarga(P1,P2)}`)

function fibonacci (n){
    n = n- 1 + n - 2
    return n
}
